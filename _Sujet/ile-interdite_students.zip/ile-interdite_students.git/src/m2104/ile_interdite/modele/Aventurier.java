package m2104.ile_interdite.modele;

/**
 *
 * @author IUT2-Dept Info
 */
public abstract class Aventurier {
}
