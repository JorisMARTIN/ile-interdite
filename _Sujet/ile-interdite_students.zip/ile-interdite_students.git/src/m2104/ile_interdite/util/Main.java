package m2104.ile_interdite.util;

import m2104.ile_interdite.controleur.Controleur;

/**
 *
 * @author Raphaël Bleuse <raphael.bleuse@iut2.univ-grenoble-alpes.fr>
 */
public class Main {

    public static void main(String[] args) {
        new Controleur();
    }

}